#include <wx/wx.h>
#include <wx/stattext.h>
#include <wx/textctrl.h>
#include <wx/button.h>
#include <wx/filename.h>
#include <cmath>

// Макрос для корректного отображения текста
#define TXT(s) wxT(s)

class MyApp : public wxApp {
public:
	virtual bool OnInit();
};

wxDECLARE_APP(MyApp);

// --- КЛАСС ВТОРОГО ОКНА ---
class ResultFrame : public wxFrame {
public:
	ResultFrame(wxFrame* parent, double b, double d, double x, double res) 
	: wxFrame(parent, wxID_ANY, TXT("Ответ"), wxDefaultPosition, wxSize(400, 350)) {
		
		wxPanel* panel = new wxPanel(this);
		wxBoxSizer* sizer = new wxBoxSizer(wxVERTICAL);
		
		wxString inputInfo = wxString::Format(
											  TXT("Входные данные:\nb = %.3f\nd = %.3f\nx = %.3f"), b, d, x);
		
		wxStaticText* lblInput = new wxStaticText(panel, wxID_ANY, inputInfo);
		lblInput->SetFont(wxFont(11, wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD));
		
		wxStaticText* lblRes = new wxStaticText(panel, wxID_ANY, wxString::Format(TXT("Результат y = %.4f"), res));
		lblRes->SetForegroundColour(*wxBLUE);
		lblRes->SetFont(wxFont(12, wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD));
		
		wxButton* btnBack = new wxButton(panel, wxID_ANY, TXT("Назад"));
		wxButton* btnExit = new wxButton(panel, wxID_ANY, TXT("Выход"));
		
		sizer->Add(lblInput, 0, wxALL | wxALIGN_CENTER, 15);
		sizer->Add(lblRes, 0, wxALL | wxALIGN_CENTER, 15);
		sizer->Add(btnBack, 0, wxALL | wxALIGN_CENTER, 5);
		sizer->Add(btnExit, 0, wxALL | wxALIGN_CENTER, 5);
		panel->SetSizer(sizer);
		
		btnBack->Bind(wxEVT_BUTTON, [this](wxCommandEvent&) { this->Close(); });
		btnExit->Bind(wxEVT_BUTTON, [](wxCommandEvent&) { wxTheApp->GetTopWindow()->Close(); });
		
		this->Bind(wxEVT_CLOSE_WINDOW, [parent, this](wxCloseEvent& e) {
			parent->Show(true);
			this->Destroy();
		});
	}
};

// --- КЛАСС ГЛАВНОГО ОКНА ---
class MainFrame : public wxFrame {
public:
	MainFrame() : wxFrame(NULL, wxID_ANY, TXT("Ввод данных"), wxDefaultPosition, wxSize(450, 450)) {
		wxPanel* panel = new wxPanel(this);
		wxBoxSizer* mainSizer = new wxBoxSizer(wxVERTICAL);
		
		wxImage::AddHandler(new wxPNGHandler());
		if (wxFileName::FileExists(TXT("task.png"))) {
			wxStaticBitmap* bmp = new wxStaticBitmap(panel, wxID_ANY, wxBitmap(TXT("task.png"), wxBITMAP_TYPE_PNG));
			mainSizer->Add(bmp, 0, wxALL | wxALIGN_CENTER, 10);
		}
		
		txtB = CreateInputRow(panel, mainSizer, TXT("Введите b:"));
		txtD = CreateInputRow(panel, mainSizer, TXT("Введите d:"));
		txtX = CreateInputRow(panel, mainSizer, TXT("Введите x:"));
		
		wxButton* btnCalc = new wxButton(panel, wxID_ANY, TXT("Вычислить"));
		mainSizer->Add(btnCalc, 0, wxALL | wxALIGN_CENTER, 20);
		
		panel->SetSizer(mainSizer);
		btnCalc->Bind(wxEVT_BUTTON, &MainFrame::OnCalculate, this);
	}
	
private:
	wxTextCtrl *txtB, *txtD, *txtX;
	
	wxTextCtrl* CreateInputRow(wxPanel* panel, wxBoxSizer* sizer, wxString labelText) {
		wxBoxSizer* row = new wxBoxSizer(wxHORIZONTAL);
		wxStaticText* lbl = new wxStaticText(panel, wxID_ANY, labelText, wxDefaultPosition, wxSize(80, -1));
		wxTextCtrl* txt = new wxTextCtrl(panel, wxID_ANY, TXT("1"));
		row->Add(lbl, 0, wxALIGN_CENTER_VERTICAL | wxRIGHT, 10);
		row->Add(txt, 1, wxEXPAND);
		sizer->Add(row, 0, wxEXPAND | wxLEFT | wxRIGHT | wxTOP, 10);
		return txt;
	}
	
	void OnCalculate(wxCommandEvent& event) {
		double b, d, x, y;
		if (!txtB->GetValue().ToDouble(&b) || !txtD->GetValue().ToDouble(&d) || !txtX->GetValue().ToDouble(&x)) {
			wxMessageBox(TXT("Введите числа!"), TXT("Ошибка"), wxOK | wxICON_ERROR);
			return;
		}
		
		if (x >= 8) {
			y = (x - 2) / (x * x);
		} else {
			y = (b * b * d) + 4 * pow(x, 3);
		}
		
		ResultFrame* resWin = new ResultFrame(this, b, d, x, y);
		resWin->Show(true);
		this->Show(false);
	}
};

bool MyApp::OnInit() {
	MainFrame* frame = new MainFrame();
	frame->Show(true);
	return true;
}

wxIMPLEMENT_APP(MyApp);
