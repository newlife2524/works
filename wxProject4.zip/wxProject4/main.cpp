#include <wx/wx.h>
#include <wx/choice.h>

// 1. Предварительные объявления
class MyFrame;

// 2. Класс приложения
class MyApp : public wxApp {
	int lang = 0;
public:
	int GetLang() { return lang; }
	void SetLang(int l); // Только объявляем
	virtual bool OnInit();
};
wxDECLARE_APP(MyApp);

// 3. Класс переводчик
class Translator {
public:
	static wxString Get(const wxString& key, int lang) {
		const wxString table[3][5] = {
			{wxT("Вітання"), wxT("Натисни мене"), wxT("Привіт!"), wxT("Українська"), wxT("Мова")},
			{wxT("Begrüßung"), wxT("Drück mich"), wxT("Hallo!"), wxT("Deutsch"), wxT("Sprache")},
			{wxT("Greeting"), wxT("Press me"), wxT("Hello!"), wxT("English"), wxT("Language")}
		};
		if (key == "RU") return wxT("Русский");
		int col = (key=="TITLE")?0:(key=="BTN")?1:(key=="MSG")?2:(key=="LANG_NAME")?3:4;
		return table[lang][col];
	}
};

// 4. Определение класса MyFrame
class MyFrame : public wxFrame {
public:
	wxButton* btn;
	wxChoice* langCh;
	wxStaticText* lbl;
	int windowLang;
	
	MyFrame(const wxString& title, int langType);
	void UpdateUI();
};

// 5. Реализация SetLang (теперь MyFrame известен)
void MyApp::SetLang(int l) {
	lang = l;
	for (auto win : wxTopLevelWindows) {
		MyFrame* f = dynamic_cast<MyFrame*>(win);
		if (f) f->UpdateUI();
	}
}

// 6. Реализация конструктора MyFrame
MyFrame::MyFrame(const wxString& title, int langType) : wxFrame(NULL, wxID_ANY, title), windowLang(langType) {
	wxPanel* p = new wxPanel(this);
	wxBoxSizer* s = new wxBoxSizer(wxVERTICAL);
	lbl = new wxStaticText(p, wxID_ANY, Translator::Get("LABEL", wxGetApp().GetLang()));
	btn = new wxButton(p, wxID_ANY, Translator::Get("BTN", wxGetApp().GetLang()));
	langCh = new wxChoice(p, wxID_ANY);
	langCh->Append(Translator::Get("RU", 0));
	langCh->Append(Translator::Get("LANG_NAME", windowLang));
	langCh->SetSelection(wxGetApp().GetLang() == windowLang ? 1 : 0);
	s->Add(lbl, 0, wxALL | wxALIGN_CENTER, 10);
	s->Add(btn, 0, wxALL | wxALIGN_CENTER, 10);
	s->Add(langCh, 0, wxALL | wxALIGN_CENTER, 10);
	p->SetSizer(s);
	btn->Bind(wxEVT_BUTTON, [&](wxCommandEvent&) { wxMessageBox(Translator::Get("MSG", wxGetApp().GetLang())); });
	langCh->Bind(wxEVT_CHOICE, [&](wxCommandEvent& e) { wxGetApp().SetLang(e.GetSelection() == 0 ? 0 : windowLang); });
}

void MyFrame::UpdateUI() {
	SetTitle(Translator::Get("TITLE", wxGetApp().GetLang()));
	lbl->SetLabel(Translator::Get("LABEL", wxGetApp().GetLang()));
	btn->SetLabel(Translator::Get("BTN", wxGetApp().GetLang()));
	langCh->SetSelection(wxGetApp().GetLang() == windowLang ? 1 : 0);
	Layout();
}

bool MyApp::OnInit() {
	(new MyFrame(wxT("UA Window"), 0))->Show();
	(new MyFrame(wxT("DE Window"), 1))->Show();
	(new MyFrame(wxT("EN Window"), 2))->Show();
	return true;
}

wxIMPLEMENT_APP(MyApp);
