#include <wx/wx.h>
#include <wx/radiobox.h>
#include <wx/listbox.h>
#include <wx/choice.h>

#define TXT(s) wxT(s)

struct UserData {
	wxString ans1 = TXT("Не выбрано"), ans2 = TXT("Не выбрано"), ans3 = TXT("Не выбрано");
};

class Page1; class Page2; class Page3; class Page4; class Page5;

class MyApp : public wxApp {
public:
	UserData data;
	Page1 *p1; Page2 *p2; Page3 *p3; Page4 *p4; Page5 *p5;
	virtual bool OnInit();
};
wxDECLARE_APP(MyApp);

class BaseFrame : public wxFrame {
public:
	BaseFrame(const wxString& title) : wxFrame(NULL, wxID_ANY, title, wxDefaultPosition, wxSize(600, 450)) {
		this->SetBackgroundColour(wxColour(200, 200, 200));
	}
};

// --- ОКОШКИ ---
class Page1 : public BaseFrame {
public:
	Page1();
};

class Page2 : public BaseFrame {
public:
	Page2(UserData* d);
};

class Page3 : public BaseFrame {
public:
	Page3(UserData* d);
};

class Page4 : public BaseFrame {
public:
	Page4(UserData* d);
};

class Page5 : public BaseFrame {
public:
	Page5(UserData* d);
};

// --- РЕАЛИЗАЦИЯ ---

Page1::Page1() : BaseFrame(TXT("Приветствие")) {
	wxPanel* p = new wxPanel(this);
	wxBoxSizer* s = new wxBoxSizer(wxVERTICAL);
	s->Add(new wxStaticText(p, wxID_ANY, TXT("Вас приветствует система анкетирования!\nТема - периоды жизни"), wxDefaultPosition, wxDefaultSize, wxALIGN_CENTER), 1, wxALIGN_CENTER | wxTOP, 50);
	
	wxButton* bNext = new wxButton(p, wxID_ANY, TXT("Начать"));
	s->Add(bNext, 0, wxALIGN_CENTER | wxBOTTOM, 20);
	p->SetSizer(s);
	bNext->Bind(wxEVT_BUTTON, [this](wxCommandEvent&) { Hide(); wxGetApp().p2->Show(); });
}

Page2::Page2(UserData* d) : BaseFrame(TXT("Детство")) {
	wxPanel* p = new wxPanel(this);
	wxBoxSizer* s = new wxBoxSizer(wxVERTICAL);
	wxString ch[] = {TXT("Манная"), TXT("Рисовая"), TXT("Гречневая")};
	wxRadioBox* rb = new wxRadioBox(p, wxID_ANY, TXT("Выберите любимую кашу"), wxDefaultPosition, wxDefaultSize, 3, ch);
	rb->Bind(wxEVT_RADIOBOX, [d, rb](wxCommandEvent&) { d->ans1 = rb->GetStringSelection(); });
	
	wxButton* bNext = new wxButton(p, wxID_ANY, TXT("Вперед"));
	bNext->Bind(wxEVT_BUTTON, [this](wxCommandEvent&) { Hide(); wxGetApp().p3->Show(); });
	
	s->Add(rb, 0, wxALL, 20); s->Add(bNext, 0, wxALL, 20);
	p->SetSizer(s);
}

Page3::Page3(UserData* d) : BaseFrame(TXT("Школа")) {
	wxPanel* p = new wxPanel(this);
	wxBoxSizer* s = new wxBoxSizer(wxVERTICAL);
	wxListBox* lb = new wxListBox(p, wxID_ANY, wxDefaultPosition, wxSize(200, 100));
	lb->Append(TXT("Отлично")); lb->Append(TXT("Хорошо"));
	lb->Bind(wxEVT_LISTBOX, [d, lb](wxCommandEvent&) { d->ans2 = lb->GetStringSelection(); });
	
	wxButton* bBack = new wxButton(p, wxID_ANY, TXT("Назад"));
	wxButton* bNext = new wxButton(p, wxID_ANY, TXT("Вперед"));
	
	bBack->Bind(wxEVT_BUTTON, [this](wxCommandEvent&) { Hide(); wxGetApp().p2->Show(); });
	bNext->Bind(wxEVT_BUTTON, [this](wxCommandEvent&) { Hide(); wxGetApp().p4->Show(); });
	
	s->Add(lb, 0, wxALL, 20); s->Add(bBack, 0, wxALL, 5); s->Add(bNext, 0, wxALL, 5);
	p->SetSizer(s);
}

Page4::Page4(UserData* d) : BaseFrame(TXT("Юность")) {
	wxPanel* p = new wxPanel(this);
	wxChoice* ch = new wxChoice(p, wxID_ANY, wxDefaultPosition, wxDefaultSize);
	ch->Append(TXT("Среднее")); ch->Append(TXT("Высшее"));
	ch->Bind(wxEVT_CHOICE, [d, ch](wxCommandEvent&) { d->ans3 = ch->GetStringSelection(); });
	
	wxButton* bBack = new wxButton(p, wxID_ANY, TXT("Назад"));
	wxButton* bNext = new wxButton(p, wxID_ANY, TXT("Вперед"));
	
	bBack->Bind(wxEVT_BUTTON, [this](wxCommandEvent&) { Hide(); wxGetApp().p3->Show(); });
	bNext->Bind(wxEVT_BUTTON, [this](wxCommandEvent&) { Hide(); wxGetApp().p5->Show(); });
	
	wxBoxSizer* s = new wxBoxSizer(wxVERTICAL);
	s->Add(ch, 0, wxALL, 20); s->Add(bBack, 0, wxALL, 5); s->Add(bNext, 0, wxALL, 5);
	p->SetSizer(s);
}

Page5::Page5(UserData* d) : BaseFrame(TXT("Результаты")) {
	wxPanel* p = new wxPanel(this);
	wxTextCtrl* tc = new wxTextCtrl(p, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE | wxTE_READONLY);
	
	this->Bind(wxEVT_SHOW, [d, tc](wxShowEvent& e) {
		if(e.IsShown()) tc->SetValue(TXT("Ваши ответы:\nДетство: ") + d->ans1 + TXT("\nШкола: ") + d->ans2 + TXT("\nЮность: ") + d->ans3);
	});
	
	wxButton* bBack = new wxButton(p, wxID_ANY, TXT("Назад"));
	wxButton* bExit = new wxButton(p, wxID_ANY, TXT("Выход"));
	
	bBack->Bind(wxEVT_BUTTON, [this](wxCommandEvent&) { Hide(); wxGetApp().p4->Show(); });
	bExit->Bind(wxEVT_BUTTON, [](wxCommandEvent&) { wxTheApp->ExitMainLoop(); });
	
	wxBoxSizer* s = new wxBoxSizer(wxVERTICAL);
	s->Add(tc, 1, wxEXPAND | wxALL, 20); 
	s->Add(bBack, 0, wxALIGN_CENTER | wxALL, 5);
	s->Add(bExit, 0, wxALIGN_CENTER | wxALL, 5);
	p->SetSizer(s);
}

bool MyApp::OnInit() {
	p1 = new Page1(); p2 = new Page2(&data); p3 = new Page3(&data);
	p4 = new Page4(&data); p5 = new Page5(&data);
	p1->Show();
	return true;
}
wxIMPLEMENT_APP(MyApp);
