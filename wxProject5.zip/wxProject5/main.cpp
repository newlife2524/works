#include <wx/wx.h>
#include <wx/listctrl.h>
#include "sqlite3.h"

// --- ДИАЛОГОВОЕ ОКНО ---
class DataDialog : public wxDialog {
public:
	wxTextCtrl *name, *founder, *year;
	DataDialog(wxWindow* parent, const wxString& title, wxString n="", wxString f="", wxString y="") 
	: wxDialog(parent, wxID_ANY, title, wxDefaultPosition, wxSize(300, 250)) {
		wxBoxSizer* s = new wxBoxSizer(wxVERTICAL);
		s->Add(new wxStaticText(this, wxID_ANY, wxString::FromUTF8("Название:")), 0, wxALL, 5);
		s->Add(name = new wxTextCtrl(this, wxID_ANY, n), 0, wxEXPAND | wxALL, 5);
		s->Add(new wxStaticText(this, wxID_ANY, wxString::FromUTF8("Основатель:")), 0, wxALL, 5);
		s->Add(founder = new wxTextCtrl(this, wxID_ANY, f), 0, wxEXPAND | wxALL, 5);
		s->Add(new wxStaticText(this, wxID_ANY, wxString::FromUTF8("Год выпуска:")), 0, wxALL, 5);
		s->Add(year = new wxTextCtrl(this, wxID_ANY, y), 0, wxEXPAND | wxALL, 5);
		s->Add(CreateButtonSizer(wxOK | wxCANCEL), 0, wxALIGN_CENTER | wxALL, 10);
		SetSizer(s);
	}
};

// --- ГЛАВНОЕ ОКНО ---
class MainFrame : public wxFrame {
	wxListCtrl* list;
	wxTextCtrl* filter;
	sqlite3* db;
	
public:
	MainFrame() : wxFrame(NULL, wxID_ANY, wxString::FromUTF8("База данных Linux"), wxDefaultPosition, wxSize(700, 500)) {
		sqlite3_open("linux.db", &db);
		sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS distros (id INTEGER PRIMARY KEY, name TEXT, founder TEXT, year TEXT);", 0,0,0);
		
		wxPanel* p = new wxPanel(this);
		wxBoxSizer* mainSizer = new wxBoxSizer(wxVERTICAL);
		wxBoxSizer* btnSizer = new wxBoxSizer(wxHORIZONTAL);
		
		filter = new wxTextCtrl(p, wxID_ANY);
		wxButton* add = new wxButton(p, wxID_ANY, wxString::FromUTF8("Добавить"));
		wxButton* edit = new wxButton(p, wxID_ANY, wxString::FromUTF8("Редактировать"));
		wxButton* del = new wxButton(p, wxID_ANY, wxString::FromUTF8("Удалить"));
		
		btnSizer->Add(filter, 1, wxALL, 5);
		btnSizer->Add(add, 0, wxALL, 5);
		btnSizer->Add(edit, 0, wxALL, 5);
		btnSizer->Add(del, 0, wxALL, 5);
		
		list = new wxListCtrl(p, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxLC_REPORT | wxLC_SINGLE_SEL);
		list->InsertColumn(0, "ID", wxLIST_FORMAT_LEFT, 50);
		list->InsertColumn(1, wxString::FromUTF8("Название"), wxLIST_FORMAT_LEFT, 200);
		list->InsertColumn(2, wxString::FromUTF8("Основатель"), wxLIST_FORMAT_LEFT, 200);
		list->InsertColumn(3, wxString::FromUTF8("Год"), wxLIST_FORMAT_LEFT, 100);
		
		mainSizer->Add(btnSizer, 0, wxEXPAND);
		mainSizer->Add(list, 1, wxEXPAND);
		p->SetSizer(mainSizer);
		
		LoadData();
		
		add->Bind(wxEVT_BUTTON, [this](wxCommandEvent&) {
			DataDialog dlg(this, wxString::FromUTF8("Добавить запись"));
			if (dlg.ShowModal() == wxID_OK) {
				sqlite3_stmt* stmt;
				sqlite3_prepare_v2(db, "INSERT INTO distros (name, founder, year) VALUES (?, ?, ?);", -1, &stmt, 0);
				sqlite3_bind_text(stmt, 1, dlg.name->GetValue().utf8_str(), -1, SQLITE_TRANSIENT);
				sqlite3_bind_text(stmt, 2, dlg.founder->GetValue().utf8_str(), -1, SQLITE_TRANSIENT);
				sqlite3_bind_text(stmt, 3, dlg.year->GetValue().utf8_str(), -1, SQLITE_TRANSIENT);
				sqlite3_step(stmt);
				sqlite3_finalize(stmt);
				LoadData();
			}
		});
		
		edit->Bind(wxEVT_BUTTON, [this](wxCommandEvent&) {
			long item = list->GetNextItem(-1, wxLIST_NEXT_ALL, wxLIST_STATE_SELECTED);
			if (item != -1) {
				wxString id = list->GetItemText(item);
				DataDialog dlg(this, wxString::FromUTF8("Редактирование"), list->GetItemText(item, 1), list->GetItemText(item, 2), list->GetItemText(item, 3));
				if (dlg.ShowModal() == wxID_OK) {
					sqlite3_stmt* stmt;
					sqlite3_prepare_v2(db, "UPDATE distros SET name=?, founder=?, year=? WHERE id=?;", -1, &stmt, 0);
					sqlite3_bind_text(stmt, 1, dlg.name->GetValue().utf8_str(), -1, SQLITE_TRANSIENT);
					sqlite3_bind_text(stmt, 2, dlg.founder->GetValue().utf8_str(), -1, SQLITE_TRANSIENT);
					sqlite3_bind_text(stmt, 3, dlg.year->GetValue().utf8_str(), -1, SQLITE_TRANSIENT);
					sqlite3_bind_int(stmt, 4, wxAtoi(id));
					sqlite3_step(stmt);
					sqlite3_finalize(stmt);
					LoadData();
				}
			}
		});
		
		del->Bind(wxEVT_BUTTON, [this](wxCommandEvent&) {
			long item = list->GetNextItem(-1, wxLIST_NEXT_ALL, wxLIST_STATE_SELECTED);
			if (item != -1 && wxMessageBox(wxString::FromUTF8("Удалить запись?"), wxString::FromUTF8("Подтверждение"), wxYES_NO) == wxYES) {
				sqlite3_exec(db, ("DELETE FROM distros WHERE id=" + list->GetItemText(item)).mb_str(), 0,0,0);
				LoadData();
			}
		});
		
		filter->Bind(wxEVT_TEXT, [this](wxCommandEvent&) { LoadData(filter->GetValue()); });
	}
	
	void LoadData(wxString search = "") {
		list->DeleteAllItems();
		sqlite3_stmt* stmt;
		wxString query = "SELECT * FROM distros WHERE name LIKE '%" + search + "%';";
		sqlite3_prepare_v2(db, query.mb_str(), -1, &stmt, 0);
		int i = 0;
		while (sqlite3_step(stmt) == SQLITE_ROW) {
			list->InsertItem(i, (char*)sqlite3_column_text(stmt, 0));
			list->SetItem(i, 1, wxString::FromUTF8((char*)sqlite3_column_text(stmt, 1)));
			list->SetItem(i, 2, wxString::FromUTF8((char*)sqlite3_column_text(stmt, 2)));
			list->SetItem(i, 3, wxString::FromUTF8((char*)sqlite3_column_text(stmt, 3)));
			i++;
		}
		sqlite3_finalize(stmt);
	}
};

class MyApp : public wxApp { public: virtual bool OnInit() { (new MainFrame())->Show(); return true; } };
wxIMPLEMENT_APP(MyApp);
